N64 Eyes
========

Animated decal textures of eyes in the style of the video game Ocarina of Time. These would be "stamped" in some way on the face of a 3D model of a character, perhaps using decal or texture atlas components of a game engine.

The textures are quite low-definition, but this is a deliberate choice to imitate the style.

Provided is:
- A texture atlas (a grid of smaller related textures) of eyes in different states.
- A source Aseprite file.
- A sample animation with and without background color.
- A folder containing separate image layers to allow editing of the eye color.
- A demonstration animation of the eyes on a 3D model.

The texture atlas is based on 32x32 px tiles. The rows of the texture atlas are eyes in pain/discomfort or in shock or in a blinking sequence. The blinking sequence does not include the eyes in shock, only those rows labelled "Blink".

The blinking and shock rows contain columns representing eyes looking forwards, left, right, up and down in that order.

The resting state of the eyes is represented in the first column of the first row of the blinking sequence.

To edit the eye color, load the files in the editing folder into image editing software. The files should be layered in the order specified in the file names, from bottom to top. Layer 2 is the flat eye color; adjust this color as desired.

Enjoy!

Version
-------

1 (2025-3-18)

License
-------

CC0 (public domain).

Credit as n64guy would be nice but is not necessary.